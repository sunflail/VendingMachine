package com.aka;

public class Client {
    public static void main(String[] args) {
        Controller control = new Controller();
        control.initialize();
    }
}